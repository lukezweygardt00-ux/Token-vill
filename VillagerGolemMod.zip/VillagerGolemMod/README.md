# Villager Golem (Minecraft 1.7.10, Forge 10.13.4.1614)

Adds a **Villager Golem Spawn Egg** (Misc creative tab). Right-click a block to spawn a Villager Golem.

* Same stats, AI and drops as an iron golem (it is an iron golem underneath).
* Shirtless, muscular villager-skinned texture (pants only).
* Plays villager idle / hurt / death sounds dropped an octave (the lowest pitch the game allows).
* The normal iron golem is unchanged and has no spawn egg.
