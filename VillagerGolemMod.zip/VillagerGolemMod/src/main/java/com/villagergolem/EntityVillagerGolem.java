package com.villagergolem;

import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.world.World;

/**
 * An iron golem (same health, AI, damage, drops) with villager noises pitched as deep as the
 * game allows. The normal iron golem is untouched; this is a separate entity.
 */
public class EntityVillagerGolem extends EntityIronGolem {

    public EntityVillagerGolem(World world) {
        super(world);
    }

    /** Every villager sound this golem makes is dropped an octave (0.5 is the game's lowest pitch). */
    @Override
    public void playSound(String name, float volume, float pitch) {
        if (name != null && name.startsWith("mob.villager")) {
            pitch = pitch * 0.5F;
            volume = volume * 1.3F;
        }
        super.playSound(name, volume, pitch);
    }

    @Override
    protected String getLivingSound() {
        return "mob.villager.idle";
    }

    @Override
    protected String getHurtSound() {
        return "mob.villager.hit";
    }

    @Override
    protected String getDeathSound() {
        return "mob.villager.death";
    }

    @Override
    protected boolean canDespawn() {
        return false;
    }
}
