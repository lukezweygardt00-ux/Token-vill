package com.villagergolem;

import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Facing;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

/** Spawn egg for the Villager Golem. Right-click a block to spawn one next to it. */
public class ItemVillagerGolemEgg extends Item {

    public ItemVillagerGolemEgg() {
        setUnlocalizedName("villagerGolemEgg");
        setTextureName(VillagerGolemMod.MODID + ":villager_golem_egg");
        setCreativeTab(CreativeTabs.tabMisc);
    }

    @Override
    public boolean onItemUse(ItemStack stack, EntityPlayer player, World world, int x, int y, int z,
                             int side, float hitX, float hitY, float hitZ) {
        if (world.isRemote) {
            return true;
        }

        Block block = world.getBlock(x, y, z);
        x += Facing.offsetsXForSide[side];
        y += Facing.offsetsYForSide[side];
        z += Facing.offsetsZForSide[side];

        if (!player.canPlayerEdit(x, y, z, side, stack)) {
            return false;
        }

        double yOffset = 0.0D;
        if (side == 1 && block.getRenderType() == 11) {
            yOffset = 0.5D;   // standing on a fence
        }

        EntityVillagerGolem golem = new EntityVillagerGolem(world);
        golem.setLocationAndAngles(x + 0.5D, y + yOffset, z + 0.5D,
                MathHelper.wrapAngleTo180_float(world.rand.nextFloat() * 360.0F), 0.0F);
        golem.rotationYawHead = golem.rotationYaw;
        golem.renderYawOffset = golem.rotationYaw;
        world.spawnEntityInWorld(golem);
        golem.playLivingSound();

        if (!player.capabilities.isCreativeMode) {
            stack.stackSize--;
        }
        return true;
    }
}
