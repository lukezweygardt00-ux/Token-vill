package com.villagergolem;

import net.minecraft.client.renderer.entity.RenderIronGolem;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;

/** Normal iron golem model and animations, with the villager-golem skin. */
public class RenderVillagerGolem extends RenderIronGolem {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(VillagerGolemMod.MODID, "textures/entity/villager_golem.png");

    @Override
    protected ResourceLocation getEntityTexture(Entity entity) {
        return TEXTURE;
    }
}
