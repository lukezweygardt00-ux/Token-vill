package com.villagergolem;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.registry.EntityRegistry;
import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.item.Item;

@Mod(modid = VillagerGolemMod.MODID, name = "Villager Golem", version = VillagerGolemMod.VERSION)
public class VillagerGolemMod {

    public static final String MODID = "villagergolem";
    public static final String VERSION = "1.0.0";

    @Mod.Instance(MODID)
    public static VillagerGolemMod instance;

    @SidedProxy(clientSide = "com.villagergolem.ClientProxy", serverSide = "com.villagergolem.CommonProxy")
    public static CommonProxy proxy;

    public static Item egg;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        EntityRegistry.registerModEntity(EntityVillagerGolem.class, "VillagerGolem", 0, this, 80, 3, true);

        egg = new ItemVillagerGolemEgg();
        GameRegistry.registerItem(egg, "villagerGolemEgg");

        proxy.registerRenderers();
    }
}
