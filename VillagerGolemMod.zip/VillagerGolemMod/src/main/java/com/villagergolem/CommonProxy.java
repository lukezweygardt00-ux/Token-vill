package com.villagergolem;

public class CommonProxy {

    public void registerRenderers() {
        // server: nothing to render
    }
}
